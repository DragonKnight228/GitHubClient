package com.example.githubclient;

import android.accounts.AccountManager;
import android.accounts.AccountManagerCallback;
import android.accounts.AccountManagerFuture;
import android.accounts.AuthenticatorException;
import android.accounts.OperationCanceledException;
import android.content.Intent;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Base64;
import android.util.JsonReader;
import android.util.Log;
import android.view.View;
import android.widget.EditText;

import androidx.activity.result.ActivityResult;
import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.browser.customtabs.CustomTabsIntent;

import net.openid.appauth.AuthorizationRequest;
import net.openid.appauth.AuthorizationService;
import net.openid.appauth.AuthorizationServiceConfiguration;
import net.openid.appauth.ResponseTypeValues;

import org.kohsuke.github.extras.HttpClientGitHubConnector;

import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;

import javax.net.ssl.HttpsURLConnection;

public class MainActivity extends AppCompatActivity {
    String userLogin;
    String userPassword;
    AuthorizationService authorizationService = new AuthorizationService(getApplication());
    AuthorizationServiceConfiguration configuration = new AuthorizationServiceConfiguration(
            Uri.parse("https://github.com/login/oauth/authorize"),
            Uri.parse("https://github.com/login/oauth/access_token"),
            null,
            Uri.parse("https://github.com/logout")
    );

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

    }

    public void Authorise(View view) throws IOException {
        CustomTabsIntent cctIntent = new CustomTabsIntent.Builder().build();

        Intent gitHubAuthorizationPage = authorizationService.getAuthorizationRequestIntent(
            getAuthorizationRequest(),
                cctIntent
        );

        private ActivityResultLauncher<String> getAuthorizationResponse = register(new ActivityResultContracts.StartActivityForResult()) {
            new ActivityResultCallback<Uri>() {
                @Override
                public void onActivityResult(Uri uri){

                }
            };
        }

    }

    public AuthorizationRequest getAuthorizationRequest() {
        Uri redirectUri = Uri.parse("ru.kts.oauth://github.com/callback");
        return new AuthorizationRequest.Builder(
                configuration,
                "0f9f8983462a5e0516fd",
                ResponseTypeValues.CODE,
                redirectUri
        ).setScope("user, repo").build();
    }



}

