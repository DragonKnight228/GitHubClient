package com.example.githubclient;

import android.accounts.AccountManagerCallback;
import android.accounts.AccountManagerFuture;
import android.os.Bundle;
import android.util.Log;

public class onError implements AccountManagerCallback<Bundle> {

    @Override
    public void run(AccountManagerFuture<Bundle> accountManagerFuture) {
        Log.println(Log.ASSERT, "Error", "Lox");
    }
}
